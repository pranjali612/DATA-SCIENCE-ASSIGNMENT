#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.formula.api as smf


# In[4]:


data= pd.read_csv("Salary_Data.csv")
data


# In[5]:


data.dtypes


# In[6]:


data.corr()


# In[16]:


data = data.rename(columns={"YearsExperience":"ye"})
data.head()


# In[17]:


plt.scatter(data.ye,data.Salary)


# In[18]:


plt.boxplot(data.ye)


# In[19]:


plt.boxplot(data.ye)


# In[21]:


plt.boxplot(data.Salary)


# In[22]:


#CRETE MODEL
model = smf.ols("Salary~ye",data=data).fit()
model.summary()


# In[23]:


sns.regplot(x="ye",y="Salary",data=data)


# In[25]:


new_data = pd.Series([1.1,10.3])
pred = pd.DataFrame(new_data,columns=["ye"])
pred


# In[26]:


model.predict(pred)


# In[27]:


data["Prediction"] = model.fittedvalues
data


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




