#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.formula.api as smf
from sklearn.linear_model import LinearRegression


# In[2]:


data = pd.read_csv('delivery_time.csv')


# In[3]:


data.head()


# In[4]:


data1 = data.rename(columns={"Delivery Time":"dt","Sorting Time":"st"})
data.head()


# In[5]:


data1.dtypes


# In[6]:


model = smf.ols("dt~st",data=data1).fit()
model.summary()


# In[7]:


xlog = np.log(data1["st"])
ylog = np.log(data1["dt"])
plt.scatter(xlog,ylog)
dlog = np.log(data1)


# In[8]:


m1 = smf.ols("dt~xlog",data=data1).fit()
m1.summary()


# In[9]:


m2 = smf.ols("ylog~st",data=data1).fit()
m2.summary()


# In[10]:


m3 = smf.ols("ylog~xlog",data=data1).fit()
m3.summary


# In[12]:


pred = pd.Series([2,8])
data_pred = pd.DataFrame(pred,columns=['xlog'])
data_pred


# In[13]:


m3.predict(data_pred)


# In[14]:


dlog["predicted"] = m3.fittedvalues
dlog


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




